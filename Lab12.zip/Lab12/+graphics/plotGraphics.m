function plotGraphics(x_data, y_data, legends, title_str, xlabel_str, ylabel_str)
    % PLOTSOLUTIONS Строит несколько наборов данных x-y на одном графике.
    %   PLOTSOLUTIONS(x_data, y_data, legends, title_str, xlabel_str, ylabel_str)
    %   строит графики. x_data и y_data должны быть массивами ячеек, где
    %   каждая ячейка содержит вектор для одного решения. legends - массив
    %   ячеек со строками для легенды.

    figure; % Создать новое окно для графика
    hold on; % Удерживать текущий график для добавления новых линий
    colors = lines(length(x_data)); % Получить набор отличимых цветов

    for i = 1:length(x_data)
        plot(x_data{i}, y_data{i}, 'LineWidth', 1.5, 'Color', colors(i,:));
    end

    title(title_str);
    xlabel(xlabel_str);
    ylabel(ylabel_str);
    legend(legends, 'Location', 'best'); % Добавить легенду
    grid on; % Включить сетку
    hold off; % Отключить удержание графика
end