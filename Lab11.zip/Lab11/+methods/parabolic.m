function [optimum_x, optimum_f, iter, history] = parabolic(func, a_init, b_init, eps, find_max)
    history = [];
    max_iter = 200;

    x1 = a_init;
    x3 = b_init;
    x2 = (x1 + x3)/2;

    % Проверка, если начальные точки уже слишком близки
    if abs(x1-x2) < eps || abs(x2-x3) < eps || abs(x1-x3) < eps
        optimum_x = x2;
        optimum_f = func(x2);
        iter = 0;
        history = [x2, optimum_f];
        return;
    end

    f1 = func(x1); history = [history; x1, f1];
    f2 = func(x2); history = [history; x2, f2];
    f3 = func(x3); history = [history; x3, f3];
    
    iter = 0;
    for k = 1:max_iter
        iter = k;
        
        % Защита от совпадающих точек, которые могут привести к den=0
        if abs(x1-x2)<eps || abs(x2-x3)<eps || abs(x1-x3)<eps
            break;
        end

        numerator = (x2 - x1)^2 * (f2 - f3) - (x2 - x3)^2 * (f2 - f1);
        denominator = 2 * ((x2 - x1)*(f2 - f3) - (x2 - x3)*(f2 - f1));

        if abs(denominator) < 1e-12 % Избегаем деления на очень малое число / ноль
            break; 
        end

        x_parab = x2 - numerator / denominator;
        
        % Простая защита от выхода за начальные границы (можно убрать, если не нужно)
        if x_parab < a_init || x_parab > b_init
            % Если выходит, можно, например, сделать шаг золотого сечения или остановиться
            % Для простоты, можно прервать, если сильно вышел
            if x_parab < a_init - (b_init-a_init) || x_parab > b_init + (b_init-a_init)
               fprintf('Парабола вышла далеко за пределы.\n');
               break;
            end
        end
        
        fx_parab = func(x_parab);
        history = [history; x_parab, fx_parab];

        % Логика обновления точек (как в примере знакомой, упрощенная)
        % Если fx_parab "хуже" текущего x2
        if (find_max && fx_parab < f2) || (~find_max && fx_parab > f2)
            if x_parab < x2
                x1 = x_parab; f1 = fx_parab;
            else % x_parab > x2
                x3 = x_parab; f3 = fx_parab;
            end
        else % fx_parab "лучше" текущего x2
            % В этой ветке важно правильно обновить все три точки, чтобы интервал сужался.
            % Логика из примера знакомой (x2 = x_parab; f2 = fx_parab;) не сужает [x1,x3].
            % Применим чуть более корректную, но все еще простую логику:
            if x_parab < x2
                x3 = x2; f3 = f2; % старый x2 становится правой границей нового интервала
            else % x_parab > x2
                x1 = x2; f1 = f2; % старый x2 становится левой границей нового интервала
            end
            x2 = x_parab; f2 = fx_parab; % x_parab - новая середина
        end
        
        % Обеспечим порядок x1 <= x2 <= x3 (на случай если что-то пошло не так)
        % и обновим f1,f2,f3, если x1,x2,x3 поменялись местами
        current_points = [x1, x2, x3];
        current_f_values = [f1, f2, f3];
        [sorted_x, sort_idx] = sort(current_points);
        x1 = sorted_x(1); x2 = sorted_x(2); x3 = sorted_x(3);
        sorted_f = current_f_values(sort_idx);
        f1 = sorted_f(1); f2 = sorted_f(2); f3 = sorted_f(3); % Это неверно, f значения нужно пересчитать для x1,x2,x3
        % Правильно:
        f1 = func(x1); f2 = func(x2); f3 = func(x3);


        if abs(x3 - x1) < eps || abs(x_parab - x2) < eps % Доп. условие на x_parab
            break;
        end
    end
    % Возвращаем x2 как результат, или лучшую из трех, или лучшую из истории.
    % Для простоты - x2, как в примере знакомой.
    optimum_x = x2; 
    optimum_f = f2; % или func(x2) для большей точности
    
    % Если результат NaN из-за проблем, вернем NaN
    if isnan(optimum_x) || isnan(optimum_f)
        optimum_x = NaN; optimum_f = NaN;
    end
end