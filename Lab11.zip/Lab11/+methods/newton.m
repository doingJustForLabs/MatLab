function [optimum_x, optimum_f, iter, history] = newton(func, df_handle, d2f_handle, bound_a, bound_b, x_start, eps, find_max)
    history = [];
    max_iter = 50; % Ньютон обычно сходится быстро или расходится
    
    x_curr = x_start;
    iter = 0;

    for k = 1:max_iter
        iter = k;
        f_val_curr = func(x_curr);
        history = [history; x_curr, f_val_curr];

        df_val = df_handle(x_curr);
        d2f_val = d2f_handle(x_curr);

        if abs(d2f_val) < 1e-10 % Вторая производная слишком мала
            optimum_x = x_curr; % Или NaN, если считать это неудачей
            optimum_f = f_val_curr;
            % fprintf('Ньютон: Вторая производная близка к нулю.\n');
            return;
        end

        % Обновление x (как в примере знакомой)
        if find_max % Ищем максимум
            x_next = x_curr + df_val / abs(d2f_val); % Обрати внимание на '+' и abs
        else % Ищем минимум
            x_next = x_curr - df_val / abs(d2f_val); % Обрати внимание на '-' и abs
        end
        
        % Проверка на большой шаг или выход за границы (как в примере знакомой)
        % abs(x_next - x_curr) > 1 --- это условие довольно специфично. 
        % Для общности можно использовать относительное изменение или просто границы.
        if abs(x_next - x_curr) > (bound_b - bound_a) || x_next < bound_a - eps || x_next > bound_b + eps % Ослабленная проверка на выход за рамки
            optimum_x = NaN; % Не сошелся в пределах разумного
            optimum_f = NaN;
            % fprintf('Ньютон: Шаг слишком большой или вышел за границы.\n');
            return;
        end

        if abs(x_next - x_curr) < eps || abs(df_val) < eps % Условие останова
             % Проверка знака второй производной (как в примере знакомой)
            if (find_max && d2f_val < -eps) || (~find_max && d2f_val > eps)
                optimum_x = x_next;
                optimum_f = func(x_next);
            else
                optimum_x = NaN; % Знак d2f не соответствует типу экстремума
                optimum_f = NaN;
                % fprintf('Ньютон: Знак второй производной не соответствует типу экстремума.\n');
            end
            return;
        end
        x_curr = x_next;
    end
    
    % Если вышли по max_iter
    optimum_x = NaN; 
    optimum_f = NaN;
    % fprintf('Ньютон: Превышено максимальное число итераций.\n');
end