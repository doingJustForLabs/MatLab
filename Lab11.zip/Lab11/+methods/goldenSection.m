function [optimum_x, optimum_f, iter, history] = goldenSection(func, a, b, eps, find_max)
    history = []; % Будем сохранять [x_candidate, f_value]
    max_iter = 200; % Ограничение на число итераций

    phi = (1 + sqrt(5)) / 2; % Золотое сечение
    
    x1 = b - (b - a) / phi;
    x2 = a + (b - a) / phi;
    
    f1 = func(x1);
    history = [history; x1, f1];
    f2 = func(x2);
    history = [history; x2, f2];

    iter = 0;
    for k = 1:max_iter
        iter = k;

        if find_max % Ищем максимум
            if f1 > f2 % f1 лучше (больше)
                b = x2;
                x2 = x1; f2 = f1;
                x1 = b - (b - a) / phi;
                f1 = func(x1);
                history = [history; x1, f1];
            else % f2 лучше (больше или равно)
                a = x1;
                x1 = x2; f1 = f2;
                x2 = a + (b - a) / phi;
                f2 = func(x2);
                history = [history; x2, f2];
            end
        else % Ищем минимум
            if f1 < f2 % f1 лучше (меньше)
                b = x2;
                x2 = x1; f2 = f1;
                x1 = b - (b - a) / phi;
                f1 = func(x1);
                history = [history; x1, f1];
            else % f2 лучше (меньше или равно)
                a = x1;
                x1 = x2; f1 = f2;
                x2 = a + (b - a) / phi;
                f2 = func(x2);
                history = [history; x2, f2];
            end
        end
        
        if abs(b-a) < eps
            break;
        end
    end
    optimum_x = (a+b)/2;
    optimum_f = func(optimum_x);
end
