function [p_optimal, f_optimal, iterations, p_history] = gradient(f_handle, grad_handle, initial_point, learning_rate, tolerance, max_iterations)
    % Метод градиентного спуска для минимизации функции f(p) двух переменных.
    %
    % Входы:
    %   f_handle       - указатель на функцию (принимает вектор-столбец p=[x;y], возвращает скаляр)
    %   grad_handle    - указатель на градиент функции (принимает вектор-столбец p, 
    %                    возвращает вектор-столбец градиента [df/dx; df/dy])
    %   initial_point  - начальная точка (вектор-столбец [x0; y0])
    %   learning_rate  - скорость обучения (alpha, шаг спуска)
    %   tolerance      - критерий остановки (малое изменение нормы шага |p_new - p_curr|)
    %   max_iterations - максимальное количество итераций
    %
    % Выходы:
    %   p_optimal      - найденная точка минимума (вектор-столбец [x_min; y_min])
    %   f_optimal      - значение функции в найденной точке минимума
    %   iterations     - количество выполненных итераций
    %   p_history      - история точек (матрица 2xN, где N - число шагов, включая начальный)
    
    p_current = initial_point(:); % Убедимся, что это вектор-столбец
    p_history = p_current;      % Первый столбец истории - начальная точка
    
    iterations = 0;
    for k = 1:max_iterations
        iterations = k;
        
        gradient_val = grad_handle(p_current); % Вычисляем градиент в текущей точке
        
        p_next = p_current - learning_rate * gradient_val; % Шаг градиентного спуска
        
        % Сохраняем точку в историю
        p_history = [p_history, p_next];
        
        % Критерий остановки: норма разницы между текущей и следующей точкой
        if norm(p_next - p_current) < tolerance
            p_current = p_next; % Обновляем текущую точку перед выходом
            break;
        end
        
        % Обновляем текущую точку для следующей итерации
        p_current = p_next;
    end
    
    p_optimal = p_current;
    f_optimal = f_handle(p_optimal);
    
    % % Если вышли по max_iterations, а условие не выполнено, можно вернуть NaN или текущее значение
    % if iterations == max_iterations && norm(p_history(:,end) - p_history(:,end-1)) >= tolerance 
    %     % fprintf('Внимание: Градиентный спуск достиг максимального числа итераций (%d) без схождения по заданной точности.\n', max_iterations);
    %     % В этом случае p_optimal и f_optimal - это последние достигнутые значения.
    %     % Можно установить f_optimal в NaN, чтобы сигнализировать о неполной сходимости, если требуется.
    %     % f_optimal = NaN; 
    % end
    
end