clear;
clc;

A = [0 2; 4 5; 3 1]
B = [1 2 3; -4 0 1]

transpose_A = transpose(A)
sum = transpose_A + B

prod = A * B
whos



