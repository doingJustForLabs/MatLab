clear;
clc;

Z = zeros(3, 3)
O = ones(1, 2)

A = rand(5, 4)
E = eye(3)
B = eye(4, 3)

M = magic(3)