clear;
clc;

A1 = linspace(1, 10);
A2 = linspace(1, 10, 5);

B = logspace(1, 3, 5)