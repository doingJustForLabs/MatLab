clear;
clc;

function n = opt_polynomial_degree(y)

    m = length(y);
    diff_table = zeros(m, m);
    diff_change = zeros(m-1, 1);
    diff_table(:, 1) = y(:);

    for j = 2:m
        for i = 1:(m-j+1)
            diff_table(i, j) = diff_table(i+1, j-1) - diff_table(i, j-1);
        end
    end
    
    fprintf('Таблица конечных разностей:\n');
    disp(diff_table);

    for k = 2:m
        diff_change(k) = max(diff_table(1:m-k+1, k)) - min(diff_table(1:m-k+1, k));
    end
    disp(diff_change');
    
    [~, min_index] = min(diff_change(2:end-1));
    n = min_index;
    fprintf('Оптимальная степень интерполяционного полинома: %d\n', n);
end

function error = interpolation_error(x, y, xx, polynomial_coeffs)
    
    y_polynomial = polyval(polynomial_coeffs, xx);
    y_real = interp1(x, y, xx, "spline");

    error = 1.0;
    for j = 1:length(xx)
        if (~ismember(x, xx(j)))
            error = error * abs(y_real(j) - y_polynomial(j));
        end
    end
end

x = [3.33;	7.47;	8.54;	9.18;	10.48;	13.97;	14.81;	15.74;	17.21];
y = [7.057;	26.442;	31.459;	50.167;	78.736;	228.149; 294.174; 363.138; 408.751];

% Степень полинома
m = 3;

W = vander(x);

coefficients = W \ y;

fprintf("Полином: P(x) = %.f6", coefficients(m+1))
for k = m:-1:1
    fprintf(' + %.6f x^%d', coefficients(k), m-k+1);
end
fprintf('\n');

n = opt_polynomial_degree(y);

x_lin = linspace(min(x), max(x), 100);
y_spline = interp1(x, y, x_lin, "spline");

y_vandermond = polyval(coefficients, x_lin);

y_polyfit = polyval(polyfit(x, y, 7), x_lin);

error = interpolation_error(x, y, linspace(min(x), max(x), 10), coefficients);
fprintf("Ошибка: %4.2f\n", error);

figure
plot(x, y, 'o', "MarkerfaceColor", "b");
hold on;
plot(x_lin, y_spline, 'r-', "LineWidth", 1);
plot(x_lin, y_vandermond, 'r-', "LineWidth", 1)
plot(x_lin, y_polyfit, '-.', "LineWidth", 1);
grid on;
legend('Данные', 'Сплайн', 'Вандермонд', 'Полином', 'Location', 'Best');